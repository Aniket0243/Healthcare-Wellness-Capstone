package com.healthcare.config;

public class SwaggerConfig {

}
