package com.healthcare.dto;

public class AppointmentDTO {

}
